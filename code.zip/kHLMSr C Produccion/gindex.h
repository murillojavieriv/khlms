#ifndef GINDEX_H_INCLUDED
#define GINDEX_H_INCLUDED
#include <math.h>
#include <list>
#include <sys/time.h>
#include <sys/resource.h>
#include <stdio.h>
#include <string.h>



struct IdxCompare
{
    const std::vector<float>& target;

    IdxCompare(const std::vector<float>& target): target(target) {}

    bool operator()(int a, int b) const { return target[a] > target[b]; }
};

struct IdxCompare2
{
    const std::vector<float>& target;

    IdxCompare2(const std::vector<float>& target): target(target) {}

    bool operator()(int a, int b) const { return target[a] < target[b]; }
};





double gindex3 ( medida & metrica , bitset<ATTRS> a );
//revisado 11-08-15

double gindex ( medida &metrica , bitset<ATTRS> a ) {  //calcula el Gindex de a, dada una metrica completa hasta K



    vector< bitset<ATTRS> > sum2, salida;
    double suma1, suma2, mv ;
    unsigned long T = 0;
    int numllamadas=0, numcomb=0;
    bitset<ATTRS> inter;
    int numsum1, numconj = a.count();


    suma1 = 0;
    Subset(a , sum2);

    for ( size_t i = 0 ; i < pow(2,ATTRS) ; i++,T++ ){

        if ( (std::bitset<ATTRS>(T) & a ).any()  ) continue;
        numsum1 =  std::bitset<ATTRS>(T).count();
        suma2 = 0;

        for ( size_t j = 0 ; j < sum2.size() ; j++ ){
                   inter = std::bitset<ATTRS>(T) | sum2[j];
                   //cout << "Original Cual: " ;  bitsetshow_num(inter);
                   if((inter.count())<=CORTE) {
                        mv = metrica.get_value( inter );
                        numllamadas++;
                   }

                   else {
                            salida.clear();
                            Combination(inter, CORTE ,salida);
                            numcomb++;

                            mv = buscar_maximo ( salida,  metrica);
                            numllamadas++;
                           // (inter.count() == ATTRS )? metrica.set_value(inter,1) : metrica.set_value(inter,mv); //si quiero ademas completar la metrica
                   }
                   if(inter.count()==ATTRS) mv=1;
                   suma2 += par( numconj - sum2[j].count()) * mv;
                   //cout << " valor: " << mv << endl;


       }
        suma1 += suma2 * (( factorial(ATTRS - numsum1 - numconj)*factorial(numsum1) ) / (factorial(ATTRS - numconj + 1)+0.0));
    }
//cout << " se llamo a mu: " << numllamadas<< " y a combination: " << numcomb << endl;
    return suma1;
}

// calcula el Gindex para todos los coeficientes de la metrica incompleta
void gindex_todos ( medida &metrica ) {

    cout << "Calculo de los Gindex " << endl;
    unsigned long T = 0;
    completar_metrica(metrica);

     for ( size_t i = 0 ; i < pow(2,ATTRS) ; i++,T++ ){

            if ( (std::bitset<ATTRS>(T)).count() == 0 ||  (std::bitset<ATTRS>(T)).count() == ATTRS ) continue;
            cout <<  "Elemento: "  << setw(ATTRS) << std::bitset<ATTRS>(T) << setw(ATTRS) ;
            bitsetshow_num( std::bitset<ATTRS>(T) );
            cout <<  " Valor: "<< setprecision(5) << gindex3( metrica, std::bitset<ATTRS>(T) ) << endl ;
     }

}




double gindex3 ( medida & metrica , bitset<ATTRS> a ) {  //calcula el Gindex de a, dada una metrica completa hasta K


    vector< bitset<ATTRS> > levelk,sum2;
    bitset<ATTRS> todos, inter, TT ;
    vector< float> vals_ord;
    vector< size_t> orden;
    double suma1, mv , fac[ATTRS+1];
    unsigned long T = 0;
    int dim , b , numllamadas=0, numconj = a.count();

    //cout <<"Paso..."<<std::flush << endl;

    for(size_t i = 0 ; i <= ATTRS ; i++ ) fac[i] = factorial(i);
    todos.set();

    //cout <<"Inicio ordenacion..."<<std::flush << endl;

    knuthcombsp( ATTRS, CORTE , levelk);
    for(size_t i = 0 ; i < levelk.size() ; i++ ) vals_ord.push_back(metrica.get_value(levelk[i]));
    for( size_t i = 0 ; i < vals_ord.size(); ++i ) orden.push_back(i);
    sort(orden.begin(), orden.end(), IdxCompare(vals_ord));

    //cout <<"Fin ordenacion..."<<std::flush << endl;


    mv=0;
    //cout <<"Inicio cuenta..."<<std::flush << endl;
    suma1 = 0;

    for ( size_t i = 0 ; i < pow(2,ATTRS) ; i++,T++ ){


        TT=std::bitset<ATTRS>(T);
        dim = TT.count();
        b = (TT & a).count();

        if(dim==ATTRS) mv=1;
        else if (dim==0) mv=0;
        else if(dim<=CORTE) { mv = metrica.get_value(TT); numllamadas++; }
        else { mv = maxlevelk(levelk,orden,metrica,TT); numllamadas++; }

        suma1 += (par(numconj - b) * mv) * (( fac[ATTRS - (dim - b) - numconj]*fac[dim - b])/(fac[ATTRS - numconj + 1]+0.0));
    }
//cout << "numllamadas: " << numllamadas << endl;
return suma1;
}




double get_process_time2() {
    struct rusage usage;
    if( 0 == getrusage(RUSAGE_SELF, &usage) ) {
        return (double)(usage.ru_utime.tv_sec + usage.ru_stime.tv_sec) +
               (double)(usage.ru_utime.tv_usec + usage.ru_stime.tv_usec) / 1.0e6;
    }
    return 0;
}




double gindex_divideandconquer ( medida &metrica , bitset<ATTRS> a, int verbose = 0 ) {
    /*calcula el Gindex de a, dada una metrica completa hasta K.  La idea es ir dividiendo el conjunto total cada ve que se examina un nuevo elemento del nivel k
    y se cuanta la cantidad de elementos hacia abajo del latice que se calculan en base a el */


   // double t_begin, t_end;
   // srand(time(NULL));


    double suma1, fac[ATTRS+1], mv=0,sum, CORTE2 = CORTE + a.count();
    size_t numconj, i, j, k, l, flag, cuantos;
    bitset<ATTRS> difconj , todos, inter, uni,  kactual, elemunion;
    vector< bitset<ATTRS> >  sum2, kordenados, levelk , sepa, listado, listado2, listado3, listado4, sal ;
    vector< float > vals_ord;
    vector< size_t > orden;
    vector < int > pornivel(ATTRS+1,0);


    numconj = a.count();
    todos.set();


    suma1 = 0;
    Subset(a , sum2);

//t_begin = get_process_time();
//-------------------------------- ordeno los elementos de nivel k ---------------------------------------

//cout << endl << "ordeno los elementos de orden k"<<std::flush << endl;
     //comb(ATTRS, CORTE, 0, 0, levelk);
    combnk(CORTE,levelk);
    //knuthcombsp( ATTRS, CORTE , levelk);
    //Combination( todos, CORTE , levelk);
    for( i = 0 ; i < levelk.size() ; i++ ) vals_ord.push_back(metrica.get_value(levelk[i]));
    for( i = 0; i < vals_ord.size(); ++i ) orden.push_back(i);
    sort(orden.begin(), orden.end(), IdxCompare(vals_ord));



//-------------------------------- fin ordeno los elementos de nivel k ---------------------------------------
 //for (i=0 ; i < levelk.size() ; i++) {  cout << levelk[orden[i]] << " - " << vals_ord[orden[i]] << " ";  bitsetshow_num(levelk[orden[i]]) ;cout << endl; }

//-------------------------------- para los del nivel hasta k lo hago de manera tradicional ---------------------------------------

    //cout <<"Cuento los coef hasta k + a"<<std::flush<<endl;

    for(i = 0 ; i <= ATTRS ; i++ ) fac[i] = factorial(i);
    int dim,b;

    for (i = 1 ; i <= CORTE2 ; i++) combnk(i,listado2);

    for (i = 0 ; i < listado2.size() ; i++){

        dim=listado2[i].count();
        b = (listado2[i] & a).count();

        if ( dim > CORTE ){
                mv = maxlevelk(levelk,orden,metrica, listado2[i]);
                metrica.add_value(listado2[i],mv);
        }
        else mv = metrica.get_value(listado2[i]);

        suma1 += (par(numconj - b) * mv) * (( fac[ATTRS - (dim - b) - numconj]*fac[dim - b])/(fac[ATTRS - numconj + 1]+0.0));
     }


//-------------------------------- fin  para los del nivel hasta k lo hago de manera tradicional ---------------------------------------

//t_end = get_process_time();
//printf( "\t\t\t paso1 : %.6f seconds\n", t_end - t_begin );

//t_begin = get_process_time();

listado2.clear();

combnk(CORTE2,listado3);
cuantos = listado3.size();

//bitsetshow(listado3);

vector < float > vals;

for ( i = 0 ; i < levelk.size() && listado2.size() < cuantos ; i++){

    for (int j=sum2.size()-1 ; j >=0 ; j--) {

        uni = sum2[j] | levelk[orden[i]];


        for ( l = 0 ; l < listado3.size() ; l++ ){

            if ( (listado3[l]&uni).count() == uni.count() ) {
                listado2.push_back(listado3[l]);
                vals.push_back(vals_ord[orden[i]]);
                listado3.erase(listado3.begin()+l);
                l--;
            }

        }

    }
}

//t_end = get_process_time();
//printf( "\t\t\t paso2 : %.6f seconds\n", t_end - t_begin );


//t_begin = get_process_time();
//-------------------------------- para los de nivel mayor a k ---------------------------------------

for (i=CORTE2+1 ; i <= ATTRS ; i++) pornivel[i]=choose(ATTRS,i); //cantidad de elementos totales para cada nivel

for (i=0 ; i < listado2.size() ; i++) { kordenados.push_back( listado2[i] ); } //listado de los elementos del nivel k ordenados

listado.push_back(todos);

//cout << "NIVEL0: " << pornivel << endl;

//t_end = get_process_time();
//printf( "\t\t\t paso3 : %.6f seconds\n", t_end - t_begin );




for( j=0 ; j < kordenados.size() && pornivel[CORTE2+1]>0 && listado.size(); j++){ // recorro los elementos del nivel k




        listado2.clear();
        listado3.clear();
        elemunion.reset();

        kactual = kordenados[j];

        //cout << "kactual" << " " << kactual << " " ;
        //bitsetshow_num(kactual);
        //cout << endl;

        //cout << "NIVEL: " << pornivel << endl;

        //float valor = metrica.get_value(kactual);
        float valor = vals[j] ;


        for(i = 0; i < listado.size() ; i++ ){
                if( (listado[i] & kactual).count() == CORTE2 ) {

                    listado2.push_back( setdiff(listado[i],kactual) ) ;
                }
                else {
                    listado3.push_back(listado[i]);
                }

        }

        if(listado2.size()==0) continue;





        for ( unsigned int i=CORTE2+1 ; i <= ATTRS && pornivel[i]>0  ;  i++ ){



            sum=0;
            //sal.clear();
            int tomadodea = i-CORTE2;
            sum = choose(listado2[0].count(),tomadodea);

            if (listado2.size() > 1){

                for( unsigned int k=1; k < listado2.size() ; k++ ){

                    listado4.clear();
                    int val= choose( listado2[k].count() ,tomadodea);
                    sum += val;


                    for(unsigned int m=0; m < k; m++){

                        sal.clear();
                        Combination2( (listado2[m]&listado2[k]),tomadodea,sal);

                        for (unsigned int l1=0 ; l1<sal.size() ; l1++){
                           flag=0;
                           for (unsigned int l2=0 ; l2<listado4.size() ; l2++){ if (listado4[l2] == sal[l1]) { flag = 1; break; }  }
                           if(!flag) listado4.push_back(sal[l1]);
                        }

                    }
                    sum-=listado4.size();


                }
            }

            if(!sum) { break; }

            //if(verbose) cout << "cuantos: " << sum << endl;


            pornivel[i] -= sum;
            //cout <<" NIVEL: " <<  pornivel <<  endl;
            int s = i - (kactual & a).count();
            if(i==ATTRS ) { valor=1; }


            //cout << "cuantos: " << sum << " valor " << valor << endl;
            //cout << "s: " << s << " signo " << par( numconj - (kactual & a).count()) << endl;

             suma1   += fac[ATTRS - s - numconj]*fac[s]/(fac[ATTRS-numconj+1]+0.0) * valor * sum * par( numconj - (kactual & a).count());


            }


        //--------------separo las listas pues ya calcule los descendientes con kactual


        sepa.clear();
        Combination2(kactual,CORTE2-1,sepa);

        for( i = 0; i < listado2.size() ; i++ ){
           if (listado2[i].count() == 1 ) continue;
           int cant = listado3.size();
           for (k=0; k<sepa.size(); k++) {

                inter = listado2[i]|sepa[k];

                flag=0;
                for (int m=0; (m < cant) && flag==0; m++)
                   if( setdiff(inter,listado3[m]).count() == 0  ) flag=1;

                if(!flag) listado3.push_back(inter);
           }
        }

        listado=listado3;



} //para cada uno de los elementos del nivel k






    return suma1;
}


double gindex_divideandconquer2 ( medida &metrica , bitset<ATTRS> a, int verbose = 0 ) {
    /*calcula el Gindex de a, dada una metrica completa hasta K.  La idea es ir dividiendo el conjunto total cada ve que se examina un nuevo elemento del nivel k
    y se cuanta la cantidad de elementos hacia abajo del latice que se calculan en base a el */

    double t_begin, t_end, sum;
    unsigned long T = 1;
    double suma1, fac[ATTRS+1], mv=0;
    size_t numconj, i, j, k, l, flag;
    bitset<ATTRS> difconj , todos, inter, kactual, elemunion;
    vector< bitset<ATTRS> >  sum2, kordenados, levelk , sepa, listado, listado2, listado3, listado4, sal ;
    vector< float > vals_ord;
    vector< size_t > orden;
    vector < int > pornivel(ATTRS+1,0);

    size_t CORTE2 = CORTE + a.count();
    numconj = a.count();
    todos.set();

t_begin = get_process_time();
    suma1 = 0;
    Subset(a , sum2);
    srand(time(NULL));

//-------------------------------- ordeno los elementos de nivel k ---------------------------------------

//cout << endl << "ordeno los elementos de orden k"<<std::flush << endl;
     //comb(ATTRS, CORTE, 0, 0, levelk);
    knuthcombsp( ATTRS, CORTE , levelk);
    //Combination( todos, CORTE , levelk);
    for( i = 0 ; i < levelk.size() ; i++ ) vals_ord.push_back(metrica.get_value(levelk[i]));
    for( i = 0; i < vals_ord.size(); ++i ) orden.push_back(i);
    sort(orden.begin(), orden.end(), IdxCompare(vals_ord));

//-------------------------------- fin ordeno los elementos de nivel k ---------------------------------------
 //for (i=0 ; i < levelk.size() ; i++) {  cout << levelk[orden[i]] << " - " << vals_ord[orden[i]] << " ";  bitsetshow_num(levelk[orden[i]]) ;cout << endl; }

//-------------------------------- para los del nivel hasta k lo hago de manera tradicional ---------------------------------------

    //cout <<"Cuento los coef hasta k + a"<<std::flush<<endl;

    for(i = 0 ; i <= ATTRS ; i++ ) fac[i] = factorial(i);
    int dim,b;

    bitset<ATTRS> TT;

    for (i = 1 ; i < pow(2,ATTRS) ; i++,T++ ){
        TT=std::bitset<ATTRS>(T);

        dim = TT.count();

        if(dim > CORTE2) continue;
        b = (TT & a).count();

        if ( dim > CORTE ){
                mv = maxlevelk(levelk,orden,metrica, TT);
                metrica.add_value(TT,mv);
        }
        else mv = metrica.get_value(TT);

        //bitsetshow_num_se(TT);
        //cout << " " << mv << endl;

        suma1 += (par(numconj - b) * mv) * (( fac[ATTRS - (dim - b) - numconj]*fac[dim - b])/(fac[ATTRS - numconj + 1]+0.0));

     }


//-------------------------------- fin  para los del nivel hasta k lo hago de manera tradicional ---------------------------------------

t_end = get_process_time();
printf( "\t\t\t  hasta aca : %.6f seconds\n", t_end - t_begin );


t_begin = get_process_time();

bitset<ATTRS> uni;
vector< bitset<ATTRS> > salida2;
listado2.clear();




knuthcombsp( ATTRS, CORTE2 , listado3);
size_t cuantos = listado3.size();

//bitsetshow(listado3);


for ( i = 0 ; i < levelk.size() && listado2.size() < cuantos ; i++){

    for (int j=sum2.size()-1 ; j >=0 ; j--) {
        //if ( (a&levelk[orden[i]]) != (sum2[j]&levelk[orden[i]]) ) continue;
        uni = sum2[j] | levelk[orden[i]];

        for ( l = 0 ; l < listado3.size() ; l++ ){

            if ( (listado3[l]&uni).count() == uni.count() ) {
                listado2.push_back(listado3[l]);
                listado3.erase(listado3.begin()+l);
                l--;
            }

        }

    }
}


//bitsetshow(listado2);
//for ( i = 0 ; i < levelk.size() ; i++)  bitsetshow_num(levelk[orden[i]]);


t_end = get_process_time();
printf( "\t\t\t ordenacion de k+a : %.6f seconds\n", t_end - t_begin );
 // for (i=0 ; i < listado2.size() ; i++) {  cout << listado2[i] <<" " ;   bitsetshow_num(listado2[i])   ; cout <<  endl; }

//-------------------------------- para los de nivel mayor a k ---------------------------------------

t_begin = get_process_time();
for (i=CORTE2+1 ; i <= ATTRS ; i++) pornivel[i]=choose(ATTRS,i); //cantidad de elementos totales para cada nivel
//if(verbose) cout << "NIVELES: " << pornivel << endl;
for (i=0 ; i < listado2.size() ; i++) { kordenados.push_back( listado2[i] ); } //listado de los elementos del nivel k ordenados

listado.push_back(todos);

//cout << "NIVEL0: " << pornivel << endl;



//for (i=0 ; i < kordenados.size() ; i++) {  cout << kordenados[i] << endl; }

for( j=0 ; j < kordenados.size() && pornivel[CORTE2+1]>0 && listado.size(); j++){ // recorro los elementos del nivel k



        listado2.clear();
        listado3.clear();
        elemunion.reset();

        kactual = kordenados[j];

        //cout << "kactual" << " " << kactual << " " ;
        //bitsetshow_num(kactual);
        //cout << endl;

        //cout << "NIVEL: " << pornivel << endl;

        float valor = metrica.get_value(kactual) ;

        for(int i = 0; i < listado.size() ; i++ ){
                if( (listado[i] & kactual).count() == CORTE2 ) {
                    elemunion = elemunion | setdiff(listado[i], kactual );
                    listado2.push_back( setdiff(listado[i],kactual) ) ;
                }
                else {
                    listado3.push_back(listado[i]);
                }

        }

        if(listado2.size()==0) continue;

        sal.clear();
        if(listado2.size()>1) Subset(elemunion, sal);

        for ( i=CORTE2+1 ; i <= ATTRS && pornivel[i]>0  ;  i++ ){



            sum=0;
            //sal.clear();
            int tomadodea = i-CORTE2;

            if (listado2.size()==1){
                    sum = choose(elemunion.count(),tomadodea);
                    //if(i==CORTE2+1) { bitsetshow_num_se(elemunion|kactual); cout << " " << valor << endl;}
            } else {


                //Combination(elemunion, tomadodea , sal);

                for( int m=0; m < sal.size(); m++){

                        if(sal[m].count()!=tomadodea) continue;

                        for( int k=0; k < listado2.size() ; k++ )
                            if ((sal[m] & listado2[k]).count() == sal[m].count() ) {
                                    sum++;
                                    /*if(i==CORTE2+1) { bitsetshow_num_se(sal[m]|kactual); cout << " " << valor <<endl; } */
                                    break;
                            }
                }
            }

            //if(!sum) { break; }

            //if(verbose) cout << "cuantos: " << sum << endl;


            pornivel[i] -= sum;
            //cout <<" NIVEL: " <<  pornivel <<  endl;
            int s = i - (kactual & a).count();
            if(i==ATTRS ) { valor=1; }


            //cout << "cuantos: " << sum << " valor " << valor << endl;
            //cout << "s: " << s << " signo " << par( numconj - (kactual & a).count()) << endl;

             suma1   += fac[ATTRS - s - numconj]*fac[s]/(fac[ATTRS-numconj+1]+0.0) * valor * sum * par( numconj - (kactual & a).count());


            }



        //--------------separo las listas pues ya calcule los descendientes con kactual
/*
        cout << "Kactual: " ; bitsetshow_num(kactual); cout << endl;
        cout << "LISTADO: " ; bitsetshow(listado) ; cout<<endl;
        cout << "LISTADO2: " ; bitsetshow(listado2) ; cout<<endl;
*/
        sepa.clear();
        Combination(kactual,CORTE2-1,sepa);

        for( i = 0; i < listado2.size() ; i++ ){
           if (listado2[i].count() == 1 ) continue;
           int cant = listado3.size();
           for (k=0; k<sepa.size(); k++) {

                inter = listado2[i]|sepa[k];

                flag=0;
                for (int m=0; (m < cant) && flag==0; m++)
                   if( setdiff(inter,listado3[m]).count() == 0  ) flag=1;

                if(!flag) listado3.push_back(inter);
           }
        }

        listado=listado3;




  //       cout << "LISTADO POST: " ; bitsetshow(listado) ; cout<<endl;


} //para cada uno de los elementos del nivel k

 //para los niveles > k

t_end = get_process_time();
printf( "\t\t\t metodo: %.6f seconds\n", t_end - t_begin );
    return suma1;



}


#endif // GINDEX_H_INCLUDED


