#ifndef DATA_MANIP_H_INCLUDED
#define DATA_MANIP_H_INCLUDED

#include <string>
#include <fstream>
#include <iostream>
#include <iterator>
#include <sstream>


//revisado 10-08-15

using namespace std;

template < class T >
ostream& operator << (ostream& os, const vector<T>& v)
{
    os << "[";
    for (typename vector<T>::const_iterator ii = v.begin(); ii != v.end(); ++ii)
    {
        os << " " << *ii;
    }
    os << "]";
    return os;
}



void read_csv (string nombre,  vector<vector<float> > &values ){

    ifstream fin(nombre.c_str());

    for (string line; getline(fin, line); )
    {
        replace(line.begin(), line.end(), ',', ' ');
        istringstream in(line);
        values.push_back( vector<float>(istream_iterator<float>(in) , istream_iterator<float>() ));
    }



}

void read_clases (string nombre,  vector< float > & clases ){

    ifstream fin(nombre.c_str());
    string line;
    getline(fin, line);
    replace(line.begin(), line.end(), ',', ' ');
    istringstream iss(line);
    float a;
    while (iss >> a) clases.push_back(a);

}


void show_csv( vector<vector<float> > values ){

    for( vector< vector<float> >::const_iterator it(values.begin()), end(values.end()); it != end; ++it) {
            copy(it->begin(), it->end(), ostream_iterator<float>(std::cout, " "));
        std::cout << "\n";
    }

}


void get_row(vector<vector<float> > values, size_t row, vector<float>  &salida ){
    salida = values[row];
}

void get_col(vector<vector<float> > values, size_t col, vector<float>  &salida ){

    for( size_t i = 0 ; i < values.size() ; i++){
        salida.push_back(values[i][col]);
    }

}




#endif // DATA_MANIP_H_INCLUDED
