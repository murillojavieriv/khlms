#ifndef HLMSR_H_INCLUDED
#define HLMSR_H_INCLUDED

//revisado 11-08-15

#include <math.h>

void nivel ( size_t nivel ,  vector< bitset<ATTRS> > caminos, vector< bitset<ATTRS> >&salida ) {  //da los elementos perteneciente a los caminos de un determinado nivel

    for(size_t i = 0 ; i < caminos.size() ; i++){
        if( caminos[i].count() == nivel ) salida.push_back(caminos[i]); ;
    }
}

vector<float> cq_todos ( vector< vector< bitset<ATTRS> > > &,  vector< vector< float > > &,  vector< bitset<ATTRS> > &, medida &  );



float c_e_p ( vector< vector< float >  >  &dat1, vector< vector< bitset<ATTRS> > > &dat2,  vector< float > &clases , vector< bitset<ATTRS> > &caminos,  medida &metrica ) { //calculo RMSE

        vector<float> salida;
        float err = 0;
        salida = cq_todos( dat2,  dat1,  caminos, metrica);

        for( size_t i = 0 ; i < clases.size() ; i++ ) err += pow(salida[i] - clases[i],2) ;

return( sqrt(err/clases.size()) );
}

void dar_caminos ( vector< vector< bitset<ATTRS> > > &cam, vector< bitset<ATTRS>  > &salida ) { // da la lista de caminos posibles considerando cam ( la lista de todos los coef del dataset )

    for(size_t i = 0 ; i < cam.size() ; i++){
         for(size_t j = ATTRS - CORTE ; j < ATTRS  ; j++){
       //  for(size_t j = 0 ; j < ATTRS  ; j++){
            size_t k = 0;
            while ( k < salida.size() && !(cam[i][j]==salida[k]) ) k++;
            if ( k==salida.size()) salida.push_back(cam[i][j]);
         }
    }
}

void descendientes ( bitset<ATTRS>  este ,  vector< bitset<ATTRS> > &caminos, vector< bitset<ATTRS> >&salida  ) { //da los descendientes de este que figuran en los caminos posibles

    bitset<ATTRS> tmp;
    size_t tam = este.count();

    for(size_t i = 0 ; i < caminos.size() ; i++){
        if(caminos[i].count() <= tam ) continue;
        tmp = (caminos[i] & este);

        if( tmp.count() ==  tam ) salida.push_back(caminos[i]);
    }
}

void desc_t ( bitset<ATTRS>  este , vector< bitset<ATTRS> >&salida  ) { //da todos los descendientes de este


    size_t tam = este.count();

    for ( size_t T = 0 ; T < pow(2,ATTRS) ; T++ ){
                if ((std::bitset<ATTRS>(T)).count() != tam + 1 ) continue;
                if( (std::bitset<ATTRS>(T) & este).count() ==  tam ) salida.push_back(std::bitset<ATTRS>(T));
    }
}



void ancestros ( bitset<ATTRS>  este ,  vector< bitset<ATTRS> > &caminos, vector< bitset<ATTRS> >&salida  ) { //da los ancestros de este que figuran en los caminos posibles

    bitset<ATTRS> tmp;
    size_t tam = este.count();

    if(tam==1) {
        salida.push_back(tmp);
        return;
    }

    for(size_t i = 0 ; i < caminos.size() ; i++){
        if(caminos[i].count() >= tam ) continue;
        tmp = (caminos[i] & este);

        if( tmp.count() == caminos[i].count() ) salida.push_back(caminos[i]);
    }
}

/*

*/

void anc_t ( bitset<ATTRS>  este ,  vector< bitset<ATTRS> >&salida  ) { //da los ancestros de este que figuran en los caminos posibles


    bitset<ATTRS> tmp;
    size_t tam = este.count();

    if(tam==1) {
        salida.push_back(tmp);
        return;
    }

    for ( size_t T = 0 ; T < pow(2,ATTRS) ; T++ ){
                if ((std::bitset<ATTRS>(T)).count() != tam - 1 ) continue;
                if( (std::bitset<ATTRS>(T) & este).count() ==  std::bitset<ATTRS>(T).count() ) salida.push_back(std::bitset<ATTRS>(T));
    }

}




void completar_metrica ( medida &metrica, vector< bitset<ATTRS> > caminos, vector< bitset<ATTRS> > dat2, vector< float > &met ){ //metrica es la cortada, los valores los devuelve en met

    vector< bitset<ATTRS> > denivel , posibles, inters;
    size_t i = 0;

    nivel ( CORTE ,  caminos, denivel );
    for(i = ATTRS - CORTE ; i < ATTRS  ; i++) met[i] = metrica.get_value(dat2[i]);

    for(i = 1 ; i < ATTRS - CORTE ; i++){

        posibles.clear();
        inters.clear();

        Subset( dat2[i] , posibles );
        inte(denivel,posibles,inters);

        met[i] = buscar_maximo ( inters,  metrica);

    }

}

float cq ( vector< bitset<ATTRS> > &dat2,  vector< float > &dat1, vector< bitset<ATTRS> > &caminos, medida &metrica ) {

    vector< float > cc(dat2.size(),1);
    float cantidad=0;

    completar_metrica( metrica, caminos, dat2, cc );

    for (size_t i = 0 ; i < dat2.size() ; i++)
        cantidad +=  dat1[i] * cc[i] ;

   return(cantidad);
}

vector <float> cq_todos( vector< vector< bitset<ATTRS> > > &dat2,  vector< vector< float > > &dat1,  vector< bitset<ATTRS> > &caminos, medida &metrica) { //calcula integral choquet para todos los datos

    vector<float> salida;

    for (size_t i = 0 ; i < dat1.size() ; i++ )
        salida.push_back( cq(dat2[i],dat1[i], caminos, metrica) );

    return(salida);
}

void chequear_up( bitset<ATTRS> cual ,  vector< bitset<ATTRS> > &caminos, medida &metrica ){ //verifica monotonicidad hacia arriba en el lattice

    float valor = metrica.get_value(cual);
    if ( valor < 0 ) {
        metrica.set_value(cual,0);
        valor = 0;
    }

    vector< bitset<ATTRS> > salida;
    ancestros( cual , caminos , salida  );

    for( size_t i=0 ; i < salida.size() ; i++){
        if ( metrica.get_value(salida[i]) > valor  ) metrica.set_value(salida[i],valor);
    }
}

void chequear_down( bitset<ATTRS> cual ,  vector< bitset<ATTRS> > &caminos, medida &metrica ){ //verifica monotonicidad hacia abajo en el lattice

    float valor = metrica.get_value(cual);
    if ( valor > 1 ) {
        metrica.set_value(cual,1);
        valor=1;
    }

    vector< bitset<ATTRS> > salida;
    descendientes( cual , caminos , salida);

    for( size_t i =0 ; i < salida.size() ; i++){
        if ( metrica.get_value(salida[i]) < valor  ) metrica.set_value(salida[i],valor);
    }
}



void paso13 ( vector< float > dat1 , vector< bitset<ATTRS> > dat2, medida &metrica, float target, vector< bitset<ATTRS>  > &caminos,  float alpha ){

    float calc  = cq( dat2, dat1, caminos, metrica);
    float error = calc - target;

    if ( error > 0 ) {
            reverse(dat2.begin(),dat2.end());
            dat2.pop_back();
    }
    else dat2.erase(dat2.begin());

    for (size_t i=0 ; i < dat2.size() ; i++ ) {

        if(dat2[i].count() > CORTE) continue;

        metrica.set_value( dat2[i],  metrica.get_value(dat2[i]) - alpha * error  * dat1[ ATTRS - dat2[i].count() ]);

        if ( error > 0){
            chequear_up(dat2[i], caminos, metrica);
        }
        else if ( error < 0) {
            chequear_down(dat2[i], caminos, metrica );
        }
    }
}


medida correr ( vector< vector< float >  >  &dat1, vector< vector< bitset<ATTRS> > > &dat2,  vector< float > clases, int clase,  size_t iter= 3000 , float alpha = 0.01){

    float e, error = 99999;
    int conv_err = 0;
    size_t i;
    vector <int> sample;
    vector< bitset<ATTRS>  > caminos;
    vector< bitset<ATTRS>  > ancestro;

    medida m , o ;
    dar_caminos( dat2 , caminos );

    cout << "The dataset has " << caminos.size() << " different coefficients belonging to class " << clase << endl;

    o.initialize(caminos, CORTE);
    m.initialize(caminos, CORTE);

    for (size_t j = 0 ; j < iter ; j++ ){
        sample.clear();
        conv_err++;
        sampleo(dat1.size(), sample);

        for (i = 0 ; i < sample.size() ; i++) {
            paso13(dat1[sample[i]], dat2[sample[i]], m, clases[sample[i]], caminos, alpha);
        }

        e = c_e_p( dat1, dat2,  clases, caminos, m );
        //cout << "Error " << e << endl;

        if( (error-e) > 0.0001 ){

            cout << "Iter: " << j << " Error: " << e << "\n";
            conv_err = 0 ;
            error    = e ;
            if(error < 0.0000001 ) break;

        }

        if( conv_err >= 20  ) break;
    }
/*
    for (size_t k = 0 ; k < caminos.size() ; k++){                           //Ajusto los que conservan el valor de inicializacion
        if (abs(m.get_value(caminos[k])-o.get_value(caminos[k])) < 0.0005 ){
                ancestros( caminos[k] , caminos, ancestro , corte );
                maximo = buscar_maximo ( ancestro,  m);
                m.set_value(caminos[k],maximo);
        }
    }

    vector< bitset<ATTRS>  > todos, estos;                                           //completo la metrica hasta el nivel de corte
    bitset<ATTRS> a;
    a.set();
    Subset(a , todos);


    for( i=0 ; i< todos.size() ; i++){
        if(todos[i].count()>corte) continue;
        if( m.get_value(todos[i]) == -1 ) {
            estos.clear();
            Subset(todos[i],estos);
            maximo = buscar_maximo ( estos,  m);
            m.set_value(todos[i],maximo);

        }
    }
*/

return(m);
}

#endif // HLMSR_H_INCLUDED
