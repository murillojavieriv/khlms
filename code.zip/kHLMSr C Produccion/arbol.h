#ifndef ARBOL_H_INCLUDED
#define ARBOL_H_INCLUDED
#include <math.h>

class nodos {

   private:
      bitset<ATTRS> nodo;
      vector < nodos > hijos;

   public:

      void set_elem( bitset<ATTRS> a ) {nodo = a;};
      void set_hijos ( vector < bitset<ATTRS> > & h );
      bitset<ATTRS> get_nodo() const {return(nodo);};
      void get_hijos( vector < bitset<ATTRS> > & h );
      void delete_hijo ( bitset<ATTRS> este);
};



void nodos::set_hijos ( vector< bitset<ATTRS> > & h) {

    for ( size_t i=0 ; i < h.size() ; i++){
        nodo * a = new nodo;
        a.set_elem(h[i]);
        hijos.push_back(a);
    };

}


void nodos::get_hijos ( vector< bitset<ATTRS> > & h) {

    for ( size_t i=0 ; i < hijos.size() ; i++) h.push_back( hijos[i].get_nodo() );

}

void nodos::delete_hijo ( bitset<ATTRS> este ) {

    for ( size_t i=0 ; i < hijos.size() ; i++) {
      if ( (hijos[i].get_nodo() & este).any() )
         hijos.erase (hijos.begin()+i);
         i--;
    }

}

class arbol {

   private:
      vector < nodos > r;

   public:

      void set_elem( bitset<ATTRS> a ) {nodo = a;};
      void set_hijos ( vector < bitset<ATTRS> > & h );
      bitset<ATTRS> get_nodo() const {return(nodo);};
      void get_hijos( vector < bitset<ATTRS> > & h );
      void delete_hijo ( bitset<ATTRS> este);
};


#endif // ARBOL_H_INCLUDED
