#include <iostream>
#include <vector>
#include <bitset>
#include <cmath>
#include <iterator>
#include <utility>
#include <algorithm>

#include <sys/time.h>
#include <sys/resource.h>

#include <stdlib.h>     /* srand, rand */
#include <time.h>       /* time */


//----------------------------------- CONFIGURACIONES DEL DATASET ----------------------------------------
// cada clase i debe tener 2 archivos de nombre clase_i_datos y clase_i_clases
// las clases valdran 1 para la clase que se esta identificando y 0 para el resto de las clases
// los valores suministrados en los datos represententan scores en [0,1] conmensurables
// los datos se separan por un espacio


#define ATTRS 4                                        //features number
#define CORTE 4                                        //k-cut value
#define CANT_CLASES 3                                      //number of clases
#define ITER 1500                                          //iteration number
#define ALPHA 0.05                                          //learning rate
#define PATH "/home/javier/Escritorio/DatasetsParaHlmsC/Iris/"             //path to datasets


//---------------------------------------------------------------------------------------------------------

#include "funciones_auxiliares.h"
#include "data_manip.h"
#include "medida.h"
#include "convertir_datos.h"
#include "hlmsr.h"
#include "gindex.h"



using namespace std;



int main()
{

// ------------------------------------------ Lectura de archivos ------------------------------------


vector<vector<float> > datos;
vector<float> clases;
string nombre,path;
stringstream ss;
vector< vector< bitset<ATTRS> > > coefs;


nombre = PATH;

medida metrica[CANT_CLASES];

srand (time(NULL));

for( size_t i = 1 ; i <= CANT_CLASES ; i++ ){


    datos.clear();
    clases.clear();
    coefs.clear();


    cout << "Procesando clase " << i <<endl;

    ss.str(string());
    ss << i;
    path = nombre;
    path.append("clase_");
    path.append(ss.str());
    path.append("_datos");
    read_csv(path,datos);

    cout << "Leyendo datos de: " << path <<endl;

    path = nombre;
    path.append("clase_");
    path.append(ss.str());
    path.append("_clases");
    read_clases(path,clases);

    cout << "Leyendo clases de: " << path <<endl;

    if(datos.size()!=clases.size()){

        cout << "\nData and class row number differ! Error!\n";
        return 1;

    }

//------------------------------------------ Conversion ------------------------------------------------

    size_t muestras = datos.size();
    vector< vector< bitset<ATTRS> > > coeficientes (muestras, vector< bitset<ATTRS> >(ATTRS)) ;
    vector< vector< float >  >  valores (muestras, vector<float>(ATTRS)) ;

    convert_data ( datos , coeficientes, valores );
    coefs = coeficientes;


//-----------------------------------------Ejecucíon ----------------------------------------------------

    metrica[i-1] = correr( valores, coeficientes,  clases, i, ITER, ALPHA );

}



cout << "Las metricas resultantes son: " << endl;

for( size_t i = 1 ; i <= CANT_CLASES ; i++ ){
    cout << endl << "--------------------------------------------------------" << endl;
    cout << "Clase: " << i << endl;
    metrica[i-1].mostrar( );
    cout << endl;
    gindex_todos( metrica[i-1] ) ;
}



    return 0;
}
