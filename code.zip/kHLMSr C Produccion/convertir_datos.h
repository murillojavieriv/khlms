#ifndef CONVERTIR_DATOS_H_INCLUDED
#define CONVERTIR_DATOS_H_INCLUDED


//revisado 10-08-15

using namespace std;

typedef pair < pair<float,size_t>, int > mypair;

bool comparation ( const mypair& l, const mypair& r){


    if(l.first.first == r.first.first ) return l.second < r.second ;
    return l.first.first < r.first.first;
}






void convert_data ( vector< vector< float > > & datosc , vector< vector< bitset<ATTRS> > > &coeficientes , vector< vector< float >  >  &valores){

//convierte la matriz de datos en dat1, dat2. Valores ya restados y a que coeficiente pertenecen.

    vector <mypair> tmp;
    size_t muestras =  datosc.size();
    bitset<ATTRS> conv;


    for (size_t i=0 ; i < muestras ; i++ ){
        tmp.clear();

        for (size_t j=0 ; j < ATTRS ; j++ ) tmp.push_back( make_pair(make_pair( datosc[i][j] ,j), rand()) );

        sort (tmp.begin(), tmp.end(), comparation);

        //matr.at(rowNumber).push_back(intValue);

        valores[i][0] = tmp[0].first.first;
        coeficientes[i][0] = conv.set();

        for ( size_t j = 1 ; j < ATTRS ; ++j){
            conv.reset();
            valores[i][j] =  tmp[j].first.first -  tmp[j-1].first.first;
            for ( size_t k = j ; k < ATTRS ; ++k) conv.set(tmp[k].first.second);
            coeficientes[i][j] =  conv ;
        }

    }

}



#endif // CONVERTIR_DATOS_H_INCLUDED
