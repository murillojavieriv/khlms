#ifndef FUNCIONES_AUXILIARES_H_INCLUDED
#define FUNCIONES_AUXILIARES_H_INCLUDED

#include <ctime>        // time
#include <cstdlib>      // rand, srand
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>


//revisado 10-08-15

using namespace std;

long factorial2(long n)
{
  long nn = n;
  return (n == 1 || n == 0) ? 1 : factorial2(n - 1) * nn;
}


double factorial(double n)
{

    return (n == 1 || n == 0) ? 1 : (tgamma(n+1));
}


int e_mat( int m1 [ATTRS+1][ATTRS+1] , int pot,  bitset<ATTRS> puntual , int sal [ATTRS+1][ATTRS+1]  )
{

    int i, j, k, l, suma=0;
    int m2[ATTRS+1][ATTRS+1];

    if(pot==0)  return( puntual.count());
    else {

        for(i=1 ; i <= ATTRS ; i++)
        {
            if (puntual[i-1]) {
                for(j=i+1 ; j<= ATTRS; j++)
                   if (puntual[j-1]) sal[i][j] = m1[i][j];

            }
        }



        for (l=1 ; l<pot ; l++)
        {

            memset(m2, 0, (ATTRS+1)*(ATTRS+1)*sizeof m2[0][0]);

            for(i=1 ; i <= ATTRS ; i++)
                for(j=i+1; j <= ATTRS; j++){
                   if(m1[i][j]==0 ) continue;
                        for(k=i+1; k <= ATTRS; k++){
                            m2[i][j] +=  sal[i][k]*m1[k][j] ;
                        }

                }



            memcpy(sal, m2 , (ATTRS+1)*(ATTRS+1)*sizeof m2[0][0]);

          cout << "mat: \n" ;
            for( int m = 0 ; m <= ATTRS  ; m++){
               for(int l = 0 ; l <= ATTRS ; l++) cout << sal[m][l] << " ";
                cout << endl;
            }

            //for(i=1 ; i <= ATTRS ; i++)
              //  for(j=i+1; j <= ATTRS; j++)
                //    sal[i][j] = m2[i][j];
        }
    }
    suma=0;
    for(i=1 ; i <= ATTRS ; i++)
       for(j=1; j <= ATTRS; j++)
            suma += sal[i][j];
    return(suma);
}



bitset<ATTRS> vecint2bitset ( vector<int> a )  //dado un vector de enteros con los coeff devuelve un bitset con esos bits encendidos
{

    bitset<ATTRS> conv;
    for(size_t i=0 ; i<a.size() ; i++)
        conv.set(a[i]);
    return conv;
}

void bitset2vecint ( bitset<ATTRS> a , vector<int>& conv)  //dado un un bitset devuelve un vector de enteros con los valores correspondientos a los bits en uno el primer bit es cero
{

    for(size_t i=0 ; i<a.size() ; i++)
        if(a[i]) conv.push_back(i);
    return;
}

void bitsetshow_num ( bitset<ATTRS> a)  //muestra un bitset con los valores numericos
{
    int b=1, bco=1;
    for(size_t i=0 ; i<a.size() ; i++)
    {
        if(a[i] && b)
        {
            cout << i+1 ;    //solo en el primer bit
            b=0;
            bco=0;
        }
        else if (a[i]) cout << "-" << i+1 ; //resto de los bits en 1
    }
    if (bco) cout << 0 ;
    cout << endl;
    return;
}




void bitsetshow ( vector< bitset<ATTRS> > a)  //muestra un conjunto de coeficientes
{
    cout << endl;

    for (size_t i = 0 ; i < a.size() ; i++)
    {
        cout << i << "-----> ";
        bitsetshow_num(a[i]);

    }


}



bitset<ATTRS> setdiff ( bitset<ATTRS> a , bitset<ATTRS> b)
{

    return  (a & b.flip() ) ;  // a\b == a \cup !b
}

/*bitset<ATTRS> xorcomp ( bitset<ATTRS> a , bitset<ATTRS> b){

        bitset<ATTRS> c ,d;
        c = a;
        d= b;
        return( (a & d.flip()) | (b & c.flip()) );

}*/




void inte ( vector< bitset<ATTRS> > &as , vector< bitset<ATTRS> > &bs, vector< bitset<ATTRS> > &salida )   //devuelve la intersecction entre dos conjuntos de coeficientes
{

    for(size_t i=0 ; i < as.size() ; i++)
    {
        for(size_t j=0 ; j < bs.size() ; j++)
        {
            if( as[i]==bs[j])
            {
                salida.push_back(as[i]);
                break;
            }
        }
    }
}

bool pertenece (  bitset<ATTRS> &este , vector< bitset<ATTRS> > &aca )   //devuelve si este pertenece aca
{

    for(size_t i=0 ; i < aca.size() ; i++)
    {
        if( (este^aca[i]).none() ) return(1);
    }

    return(0);
}

void Combination(bitset<ATTRS> estos, size_t tomadosdea , vector< bitset<ATTRS> >& salida )  //devuelva las combinaciones de los att tomadosdea
{


    unsigned long T = 0;
    vector<size_t> posiciones;
    bitset<ATTRS> a;
    size_t cant1 = estos.count();

    for ( size_t i = 0 ; i < ATTRS ; i++ )
        if(estos[i]) posiciones.push_back(i);

    for ( size_t i = 0 ; i < pow(2,cant1) ; i++,T++ )
    {
        if ((std::bitset<ATTRS>(T)).count() != tomadosdea) continue;
        a.reset();
        for ( size_t j = 0 ; j < cant1 ; j++ )
            if ( (std::bitset<ATTRS>(T))[j] ) a.set(posiciones[j]);
        salida.push_back(a);
    }
}






void Subset( bitset<ATTRS> estos, vector< bitset<ATTRS> >& salida ) //devuelve todos los subconjuntos de estos
{
    unsigned long T = 0;
    vector<size_t> posiciones;
    bitset<ATTRS> a;
    size_t cant1 = estos.count();

    for ( size_t i = 0 ; i < ATTRS ; i++ )
        if(estos[i]) posiciones.push_back(i);

    for ( size_t i = 0 ; i < pow(2,cant1) ; i++,T++ )
    {
        a.reset();
        for ( size_t j = 0 ; j < cant1 ; j++ )
            if ( (std::bitset<ATTRS>(T))[j] ) a.set(posiciones[j]);
        salida.push_back(a);
    }
    return;
}






long choose(long n , long m)  // calcula n tomado de a m
{
    if(m>n || m<0 || n<0) return(0);
    if(m==0) return 1;
    long mult=1;
    int i;
    for (i=(n-m)+1; i<=n; i++) mult *= i;
    return mult/factorial(m)  ;


    // return( (factorial(n)+0.0)/(factorial(n-m)*factorial(m)) );
}

void sampleo (size_t cuantos, vector <int> &sample )  // devuelve un arreglo aleatorio de los elementos del 1 a cuantos
{

    srand (unsigned (time(0))); //seed
    for (size_t i=0; i<cuantos; ++i) sample.push_back(i);
    random_shuffle ( sample.begin(), sample.end() );

}



int sign ( int a)  //funcion signo
{
    return (a<0)? -1 : 1;
}


int par ( int a)  //funcion paridad
{
    return (a%2)? -1 : 1;
}



/* Algorithm by Donald Knuth. */

void knuthcomb ( int n, int k, vector < bitset<ATTRS> > & este, vector<size_t> posiciones )
{


    int i,  *c, x , j=1;
    bitset<ATTRS> a;

    if (n <= k) return;
    //if (n == k) { a.set();  este.push_back(a); return; }

    c = (int*)malloc( (k+3) * sizeof(int));

    for (i=1; i <= k; i++) c[i] = i;
    c[k+1] = n+1;
    c[k+2] = 0;
    j = k;
visit:
    for (i=k; i >= 1; i--)
    {
        a.set(posiciones[c[i]-1]);
    }
    este.push_back(a);

    a.reset();
    if (j > 0)
    {
        x = j+1;
        goto incr;
    }
    if (c[1] + 1 < c[2])
    {
        c[1] += 1;
        goto visit;
    }
    j = 2;
do_more:
    c[j-1] = j-1;
    x = c[j] + 1;
    if (x == c[j+1])
    {
        j++;
        goto do_more;
    }
    if (j > k)
    {
        return;
    }
incr:
    c[j] = x;
    j--;
    goto visit;

}

void knuthcombsp ( int n, int k, vector < bitset<ATTRS> > & este )
{
    int i,  *c, x , j=1;
    bitset<ATTRS> a;

    if (n < k) return;
    if (n == k)
    {
        a.set();
        este.push_back(a);
        return;
    }

    c = (int*)malloc( (k+3) * sizeof(int));

    for (i=1; i <= k; i++) c[i] = i;
    c[k+1] = n+1;
    c[k+2] = 0;
    j = k;
visit:
    for (i=k; i >= 1; i--)
    {
        a.set(c[i]-1);
    }
    este.push_back(a);
    a.reset();
    if (j > 0)
    {
        x = j+1;
        goto incr;
    }
    if (c[1] + 1 < c[2])
    {
        c[1] += 1;
        goto visit;
    }
    j = 2;
do_more:
    c[j-1] = j-1;
    x = c[j] + 1;
    if (x == c[j+1])
    {
        j++;
        goto do_more;
    }
    if (j > k)
    {
        return;
    }
incr:
    c[j] = x;
    j--;
    goto visit;

}

void knuthcomborig ( int n, int k)
{
    int i,  *c, x , j=1;

    c = (int*)malloc( (k+3) * sizeof(int));

    for (i=1; i <= k; i++) c[i] = i;
    c[k+1] = n+1;
    c[k+2] = 0;
    j = k;
visit:
    for (i=k; i >= 1; i--) printf( "%3d", c[i]);
    printf( "\n");
    if (j > 0)
    {
        x = j+1;
        goto incr;
    }
    if (c[1] + 1 < c[2])
    {
        c[1] += 1;
        goto visit;
    }
    j = 2;
do_more:
    c[j-1] = j-1;
    x = c[j] + 1;
    if (x == c[j+1])
    {
        j++;
        goto do_more;
    }
    if (j > k) exit(0);
incr:
    c[j] = x;
    j--;
    goto visit;
}



#endif // FUNCIONES_AUXILIARES_H_INCLUDED
