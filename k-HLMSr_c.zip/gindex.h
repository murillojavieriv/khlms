#ifndef GINDEX_H_INCLUDED
#define GINDEX_H_INCLUDED
#include <math.h>
#include <list>
#include <sys/time.h>
#include <sys/resource.h>
#include <stdio.h>
#include <string.h>



//revisado 11-08-15

double gindex ( medida &metrica , bitset<ATTRS> a ) {  //calcula el Gindex de a, dada una metrica completa hasta K



    vector< bitset<ATTRS> > sum2, salida;
    double suma1, suma2, mv ;
    unsigned long T = 0;
    int numllamadas=0, numcomb=0;
    bitset<ATTRS> inter;
    int numsum1, numconj = a.count();


    suma1 = 0;
    Subset(a , sum2);

    for ( size_t i = 0 ; i < pow(2,ATTRS) ; i++,T++ ){

        if ( (std::bitset<ATTRS>(T) & a ).any()  ) continue;
        numsum1 =  std::bitset<ATTRS>(T).count();
        suma2 = 0;

        for ( size_t j = 0 ; j < sum2.size() ; j++ ){
                   inter = std::bitset<ATTRS>(T) | sum2[j];
                   //cout << "Original Cual: " ;  bitsetshow_num(inter);
                   if((inter.count())<=CORTE) {
                        mv = metrica.get_value( inter );
                        numllamadas++;
                   }

                   else {
                            salida.clear();
                            Combination(inter, CORTE ,salida);
                            numcomb++;

                            mv = buscar_maximo ( salida,  metrica);
                            numllamadas++;
                           // (inter.count() == ATTRS )? metrica.set_value(inter,1) : metrica.set_value(inter,mv); //si quiero ademas completar la metrica
                   }
                   if(inter.count()==ATTRS) mv=1;
                   suma2 += par( numconj - sum2[j].count()) * mv;
                   //cout << " valor: " << mv << endl;


       }
        suma1 += suma2 * (( factorial(ATTRS - numsum1 - numconj)*factorial(numsum1) ) / (factorial(ATTRS - numconj + 1)+0.0));
    }
//cout << " se llamo a mu: " << numllamadas<< " y a combination: " << numcomb << endl;
    return suma1;
}

// calcula el Gindex para todos los coeficientes de la metrica incompleta
void gindex_todos ( medida &metrica ) {

    cout << "Calculo de los Gindex " << endl;
    unsigned long T = 0;
    completar_metrica(metrica);

     for ( size_t i = 0 ; i < pow(2,ATTRS) ; i++,T++ ){

            if ( (std::bitset<ATTRS>(T)).count() == 0 ||  (std::bitset<ATTRS>(T)).count() == ATTRS ) continue;
            cout <<  "Elemento: "  << setw(ATTRS) << std::bitset<ATTRS>(T) << setw(ATTRS) <<  " Valor: "<< setprecision(5) << gindex( metrica, std::bitset<ATTRS>(T) ) << endl ;
     }

}


struct IdxCompare
{
    const std::vector<float>& target;

    IdxCompare(const std::vector<float>& target): target(target) {}

    bool operator()(int a, int b) const { return target[a] > target[b]; }
};

struct IdxCompare2
{
    const std::vector<float>& target;

    IdxCompare2(const std::vector<float>& target): target(target) {}

    bool operator()(int a, int b) const { return target[a] < target[b]; }
};



double gindex2 ( medida & metrica , bitset<ATTRS> a ) {  //calcula el Gindex de a, dada una metrica completa hasta K


    vector< bitset<ATTRS> > levelk,sum2;
    bitset<ATTRS> todos, inter;
    vector< float> vals_ord;
    vector< size_t> orden;
    double suma1, suma2, mv ;
    unsigned long T = 0;
    int numsum1,numllamadas=0, numconj = a.count();

    cout <<"Paso..."<<std::flush << endl;

    todos.set();

    cout <<"Inicio ordenacion..."<<std::flush << endl;

    Combination( todos, CORTE , levelk);
    for(size_t i = 0 ; i < levelk.size() ; i++ ) vals_ord.push_back(metrica.get_value(levelk[i]));
    for( size_t i = 0 ; i < vals_ord.size(); ++i ) orden.push_back(i);
    sort(orden.begin(), orden.end(), IdxCompare(vals_ord));

    cout <<"Fin ordenacion..."<<std::flush << endl;



    cout <<"Inicio cuenta..."<<std::flush << endl;
    suma1 = 0;
    Subset(a , sum2);

    for ( size_t i = 0 ; i < pow(2,ATTRS) ; i++,T++ ){

        if ( (std::bitset<ATTRS>(T) & a ).any()  ) continue;
        numsum1 =  std::bitset<ATTRS>(T).count();
        suma2 = 0;

        for ( size_t j = 0 ; j < sum2.size() ; j++ ){
                   inter = std::bitset<ATTRS>(T) | sum2[j];
                   //cout << "Original Cual: " ;  bitsetshow_num(inter);

                    if(inter.count()==ATTRS) mv=1;
                    else if (inter.count()==0) mv=0;
                    else if((inter.count())<=CORTE) {
                        mv = metrica.get_value( inter );
                        numllamadas++;
                    }
                    else {
                            mv = maxlevelk(levelk,orden,metrica,inter);
                            numllamadas++;
                   }


                   suma2 += par( numconj - sum2[j].count()) * mv;
                   //cout << " valor: " << mv << endl;
       }

       suma1 += suma2 * (( factorial(ATTRS - numsum1 - numconj)*factorial(numsum1) ) / (factorial(ATTRS - numconj + 1)+0.0));
     }
     cout << "Fin cuenta...." << endl << "Se llamo a mu: " << numllamadas << endl;
return suma1;
}



double get_process_time2() {
    struct rusage usage;
    if( 0 == getrusage(RUSAGE_SELF, &usage) ) {
        return (double)(usage.ru_utime.tv_sec + usage.ru_stime.tv_sec) +
               (double)(usage.ru_utime.tv_usec + usage.ru_stime.tv_usec) / 1.0e6;
    }
    return 0;
}



#endif // GINDEX_H_INCLUDED


