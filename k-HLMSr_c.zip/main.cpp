#include <iostream>
#include <vector>
#include <bitset>
#include <cmath>
#include <iterator>
#include <utility>
#include <algorithm>

#include <sys/time.h>
#include <sys/resource.h>




//----------------------------------- CONFIGURACIONES DEL DATASET ----------------------------------------
// cada clase i debe tener 2 archivos de nombre clase_i_datos y clase_i_clases
// las clase valdra 1 para la clase que se esta identificando y 0 en otro caso
// los valores suministrados en los datos represententan scores en [0,1] conmensurables
// los datos se separan por un espacio


#define ATTRS 15                                            //number of features
#define CORTE 2                                             //k-cut value
#define CANT_CLASES 2                                      //number of classes
#define ITER 3000                                          //iteration number
#define ALPHA 0.01                                         //learning rate
#define PATH "/home/javier/datasets/"                       //path to datasets


//---------------------------------------------------------------------------------------------------------

#include "funciones_auxiliares.h"
#include "data_manip.h"
#include "medida.h"
#include "convertir_datos.h"
#include "hlmsr.h"
#include "gindex.h"



using namespace std;

double get_process_time() {
    struct rusage usage;
    if( 0 == getrusage(RUSAGE_SELF, &usage) ) {
        return (double)(usage.ru_utime.tv_sec + usage.ru_stime.tv_sec) +
               (double)(usage.ru_utime.tv_usec + usage.ru_stime.tv_usec) / 1.0e6;
    }
    return 0;
}

int main()
{


// ------------------------------------------ Lectura de archivos ------------------------------------


vector<vector<float> > datos;
vector<float> clases;
string nombre,path;
stringstream ss;
vector< vector< bitset<ATTRS> > > coefs;


nombre = PATH;

medida metrica[CANT_CLASES];

for( size_t i = 1 ; i <= CANT_CLASES ; i++ ){


    datos.clear();
    clases.clear();
    coefs.clear();


    cout << "Procesando clase " << i <<endl;

    ss.str(string());
    ss << i;
    path = nombre;
    path.append("clase_");
    path.append(ss.str());
    path.append("_datos");
    read_csv(path,datos);

    cout << "Leyendo datos de: " << path <<endl;

    path = nombre;
    path.append("clase_");
    path.append(ss.str());
    path.append("_clases");
    read_clases(path,clases);

    cout << "Leyendo clases de: " << path <<endl;



//------------------------------------------ Conversion ------------------------------------------------

    size_t muestras = datos.size();
    vector< vector< bitset<ATTRS> > > coeficientes (muestras, vector< bitset<ATTRS> >(ATTRS)) ;
    vector< vector< float >  >  valores (muestras, vector<float>(ATTRS)) ;

    convert_data ( datos , coeficientes, valores );
    coefs = coeficientes;

//-----------------------------------------Ejecucíon ----------------------------------------------------

    metrica[i-1] = correr( valores, coeficientes,  clases, i, ITER, ALPHA );

}



cout << "Las metricas resultantes son: " << endl;

for( size_t i = 1 ; i <= CANT_CLASES ; i++ ){
    cout << endl << "--------------------------------------------------------" << endl;
    cout << "Clase: " << i << endl;
    metrica[i-1].mostrar( );
    cout << endl;
    //completar_metrica( metrica[i-1] , coefs,  CORTE );
    gindex_todos( metrica[i-1] ) ;

}




    return 0;
}
