#ifndef FUNCIONES_AUXILIARES_H_INCLUDED
#define FUNCIONES_AUXILIARES_H_INCLUDED

#include <ctime>        // time
#include <cstdlib>      // rand, srand
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>


//revisado 10-08-15

using namespace std;

double get_process_time() {
    struct rusage usage;
    if( 0 == getrusage(RUSAGE_SELF, &usage) ) {
        return (double)(usage.ru_utime.tv_sec + usage.ru_stime.tv_sec) +
               (double)(usage.ru_utime.tv_usec + usage.ru_stime.tv_usec) / 1.0e6;
    }
    return 0;
}



long factorial(long n)
{
  long nn = n;
  return (n == 1 || n == 0) ? 1 : factorial(n - 1) * nn;
}


double factorial2(double n)
{

    return (n == 1 || n == 0) ? 1 : (tgamma(n+1));
}





bitset<ATTRS> vecint2bitset ( vector<int> a )  //dado un vector de enteros con los coeff devuelve un bitset con esos bits encendidos
{

    bitset<ATTRS> conv;
    for(size_t i=0 ; i<a.size() ; i++)
        conv.set(a[i]);
    return conv;
}

void bitset2vecint ( bitset<ATTRS> a , vector<int>& conv)  //dado un un bitset devuelve un vector de enteros con los valores correspondientos a los bits en uno el primer bit es cero
{

    for(size_t i=0 ; i<a.size() ; i++)
        if(a[i]) conv.push_back(i);
    return;
}

void bitsetshow_num ( bitset<ATTRS> a)  //muestra un bitset con los valores numericos
{
    int b=1, bco=1;
    for(size_t i=0 ; i<a.size() ; i++)
    {
        if(a[i] && b)
        {
            cout << i+1 ;    //solo en el primer bit
            b=0;
            bco=0;
        }
        else if (a[i]) cout << "-" << i+1 ; //resto de los bits en 1
    }
    if (bco) cout << 0 ;
    cout << endl;
    return;
}

void bitsetshow_num_se ( bitset<ATTRS> a)  //muestra un bitset con los valores numericos
{
    int b=1, bco=1;
    for(size_t i=0 ; i<a.size() ; i++)
    {
        if(a[i] && b)
        {
            cout << i+1 ;    //solo en el primer bit
            b=0;
            bco=0;
        }
        else if (a[i]) cout << "-" << i+1 ; //resto de los bits en 1
    }
    if (bco) cout << 0 ;
    //cout << endl;
    return;
}



void bitsetshow ( vector< bitset<ATTRS> > a)  //muestra un conjunto de coeficientes
{
    cout << endl;

    for (size_t i = 0 ; i < a.size() ; i++)
    {
        cout << i << "-----> ";
        bitsetshow_num(a[i]);

    }


}



typedef unsigned long marker;
marker one = 1;

void comb(int pool, int need, marker chosen, int at , vector< bitset<ATTRS>  > &sal) //, vector< size_t  > & pos)
{
	if (pool < need + at) return; /* not enough bits left */

	if (!need) {
		/* got all we needed; print the thing.  if other actions are
		 * desired, we could have passed in a callback function. */
		bitset<ATTRS> este;
		for (at = 0; at < pool; at++)
			if (chosen & (one << at)) este.set(at);//printf("%d ", at+1);
			//if (chosen & (one << at)) este.set(pos[at]);//printf("%d ", at+1);
		sal.push_back(este);
		return;
	}
	/* if we choose the current item, "or" (|) the bit to mark it so. */
	comb(pool, need - 1, chosen | (one << at), at + 1,sal);//,pos);
	comb(pool, need, chosen, at + 1,sal);//,pos);  /* or don't choose it, go to next */
}





bitset<ATTRS> setdiff ( bitset<ATTRS> a , bitset<ATTRS> b)
{

    return  (a & b.flip() ) ;  // a\b == a \cup !b
}

/*bitset<ATTRS> xorcomp ( bitset<ATTRS> a , bitset<ATTRS> b){

        bitset<ATTRS> c ,d;
        c = a;
        d= b;
        return( (a & d.flip()) | (b & c.flip()) );

}*/




void inte ( vector< bitset<ATTRS> > &as , vector< bitset<ATTRS> > &bs, vector< bitset<ATTRS> > &salida )   //devuelve la intersecction entre dos conjuntos de coeficientes
{

    for(size_t i=0 ; i < as.size() ; i++)
    {
        for(size_t j=0 ; j < bs.size() ; j++)
        {
            if( as[i]==bs[j])
            {
                salida.push_back(as[i]);
                break;
            }
        }
    }
}

bool pertenece (  bitset<ATTRS> &este , vector< bitset<ATTRS> > &aca )   //devuelve si este pertenece aca
{

    for(size_t i=0 ; i < aca.size() ; i++)
    {
        if( (este^aca[i]).none() ) return(1);
    }

    return(0);
}

void Combination(bitset<ATTRS> estos, size_t tomadosdea , vector< bitset<ATTRS> >& salida )  //devuelva las combinaciones de los att tomadosdea
{


    unsigned long T = 0;
    vector<size_t> posiciones;
    bitset<ATTRS> a;
    size_t cant1 = estos.count();

    for ( size_t i = 0 ; i < ATTRS ; i++ )
        if(estos[i]) posiciones.push_back(i);

    for ( size_t i = 0 ; i < pow(2,cant1) ; i++,T++ )
    {
        if ((std::bitset<ATTRS>(T)).count() != tomadosdea) continue;
        a.reset();
        for ( size_t j = 0 ; j < cant1 ; j++ )
            if ( (std::bitset<ATTRS>(T))[j] ) a.set(posiciones[j]);
        salida.push_back(a);
    }
}


unsigned long choose(unsigned long n, unsigned long k) {
    if (k > n) {
        return 0;
    }
    unsigned long r = 1;
    for (unsigned long d = 1; d <= k; ++d) {
        r *= n--;
        r /= d;
    }
    return r;
}


void combnk( int k , vector< bitset<ATTRS> >& salida  ) //version rapida de combinaciones de ATTRS tomados de k elementos
{
    int i;
    bitset<ATTRS> a;
    for ( i=0; i < k ; i++ ) a.set(i);

    salida.push_back(a);
    unsigned int v; // current permutation of bits
    unsigned int w; // next permutation of bits

    v=a.to_ulong();



    for (i=0; (unsigned int) i < choose(ATTRS,k)-1 ; i++ ) {

        unsigned int t = v | (v - 1); // t gets v's least significant 0 bits set to 1
        // Next set to 1 the most significant bit to change,
        // set to 0 the least significant ones, and add the necessary 1 bits.
        w = (t + 1) | (((~t & -~t) - 1) >> (__builtin_ctz(v) + 1));
        salida.push_back(std::bitset<ATTRS>(w));
        v=w;
    }

}


void combnk2(int n,  int k , vector< bitset<ATTRS> >& salida  ) //version rapida de combinaciones de ATTRS tomados de k elementos
{

    unsigned int v=1; // current permutation of bits
    unsigned int w; // next permutation of bits

    for (int i=1; i < k ; i++ ) { v=v<<1; v=(v|1); }

    salida.push_back(v);

    for (int i=0; (unsigned int) i < choose(n,k)-1 ; i++ ) {

        unsigned int t = v | (v - 1); // t gets v's least significant 0 bits set to 1
        // Next set to 1 the most significant bit to change,
        // set to 0 the least significant ones, and add the necessary 1 bits.
        w = (t + 1) | (((~t & -~t) - 1) >> (__builtin_ctz(v) + 1));
        salida.push_back(std::bitset<ATTRS>(w));
        v=w;
    }

}

void Combination2 (bitset<ATTRS> estos, size_t tomadosdea , vector< bitset<ATTRS> >& salida )  //devuelva las combinaciones de los att tomadosdea
{

    vector<size_t> posiciones;
    bitset<ATTRS> a;
    size_t i,j, cant1 = estos.count();
    vector< bitset<ATTRS> > salida2;
    if (tomadosdea>cant1) { return;}
    if (tomadosdea==0) { salida.push_back(a); return;}

    for ( i = 0 ; i < ATTRS ; i++ )
        if(estos[i]) posiciones.push_back(i);

    combnk2(cant1,tomadosdea,salida2);

    for ( i = 0 ; i < salida2.size() ; i++ )
    {
        a.reset();
        for ( j = 0 ; j < cant1 ; j++ )
            if ( (salida2[i])[j] ) a.set(posiciones[j]);
        salida.push_back(a);
    }
}




void Subset( bitset<ATTRS> estos, vector< bitset<ATTRS> >& salida ) //devuelve todos los subconjuntos de estos
{

    unsigned long T = 0;
    vector<size_t> posiciones;
    bitset<ATTRS> a;
    size_t cant1 = estos.count();

    for ( size_t i = 0 ; i < ATTRS ; i++ )
        if(estos[i]) posiciones.push_back(i);

    for ( size_t i = 0 ; i < pow(2,cant1) ; i++,T++ )
    {
        a.reset();
        for ( size_t j = 0 ; j < cant1 ; j++ )
            if ( (std::bitset<ATTRS>(T))[j] ) a.set(posiciones[j]);
        salida.push_back(a);
    }
    return;

}


void sampleo (size_t cuantos, vector <int> &sample )  // devuelve un arreglo aleatorio de los elementos del 1 a cuantos
{

    srand (unsigned (time(0))); //seed
    for (size_t i=0; i<cuantos; ++i) sample.push_back(i);
    random_shuffle ( sample.begin(), sample.end() );

}



int sign ( int a)  //funcion signo
{
    return (a<0)? -1 : 1;
}


int par ( int a)  //funcion paridad
{
    return (a%2)? -1 : 1;
}



/* Algorithm by Donald Knuth. */

void knuthcomb ( int n, int k, vector < bitset<ATTRS> > & este, vector<size_t> posiciones )
{


    int i,  *c, x , j=1;
    bitset<ATTRS> a;

    if (n <= k) return;
    //if (n == k) { a.set();  este.push_back(a); return; }

    c = (int*)malloc( (k+3) * sizeof(int));

    for (i=1; i <= k; i++) c[i] = i;
    c[k+1] = n+1;
    c[k+2] = 0;
    j = k;
visit:
    for (i=k; i >= 1; i--)
    {
        a.set(posiciones[c[i]-1]);
    }
    este.push_back(a);

    a.reset();
    if (j > 0)
    {
        x = j+1;
        goto incr;
    }
    if (c[1] + 1 < c[2])
    {
        c[1] += 1;
        goto visit;
    }
    j = 2;
do_more:
    c[j-1] = j-1;
    x = c[j] + 1;
    if (x == c[j+1])
    {
        j++;
        goto do_more;
    }
    if (j > k)
    {
        return;
    }
incr:
    c[j] = x;
    j--;
    goto visit;

}

void knuthcombsp ( int n, int k, vector < bitset<ATTRS> > & este )
{
    int i,  *c, x , j=1;
    bitset<ATTRS> a;

    if (n < k) return;
    if (n == k)
    {
        a.set();
        este.push_back(a);
        return;
    }

    c = (int*)malloc( (k+3) * sizeof(int));

    for (i=1; i <= k; i++) c[i] = i;
    c[k+1] = n+1;
    c[k+2] = 0;
    j = k;
visit:
    for (i=k; i >= 1; i--)
    {
        a.set(c[i]-1);
    }
    este.push_back(a);
    a.reset();
    if (j > 0)
    {
        x = j+1;
        goto incr;
    }
    if (c[1] + 1 < c[2])
    {
        c[1] += 1;
        goto visit;
    }
    j = 2;
do_more:
    c[j-1] = j-1;
    x = c[j] + 1;
    if (x == c[j+1])
    {
        j++;
        goto do_more;
    }
    if (j > k)
    {
        return;
    }
incr:
    c[j] = x;
    j--;
    goto visit;

}

void knuthcomborig ( int n, int k)
{
    int i,  *c, x , j=1;

    c = (int*)malloc( (k+3) * sizeof(int));

    for (i=1; i <= k; i++) c[i] = i;
    c[k+1] = n+1;
    c[k+2] = 0;
    j = k;
visit:
    for (i=k; i >= 1; i--) printf( "%3d", c[i]);
    printf( "\n");
    if (j > 0)
    {
        x = j+1;
        goto incr;
    }
    if (c[1] + 1 < c[2])
    {
        c[1] += 1;
        goto visit;
    }
    j = 2;
do_more:
    c[j-1] = j-1;
    x = c[j] + 1;
    if (x == c[j+1])
    {
        j++;
        goto do_more;
    }
    if (j > k) exit(0);
incr:
    c[j] = x;
    j--;
    goto visit;
}



#endif // FUNCIONES_AUXILIARES_H_INCLUDED
