#ifndef MEDIDA_H_INCLUDED
#define MEDIDA_H_INCLUDED


#include <vector>
#include <bitset>
#include <cmath>
#include <iterator>
#include <algorithm>
#include <iomanip>
#include <stdio.h>

using namespace std;


//revisado 10-08-15



class coef {

   private:
      float  valor;
      bitset<ATTRS> elem;

   public:
      void set_elem( vector<int>);
      void set_elem( bitset<ATTRS> a ) {elem = a;};
      void set_value( float a) {valor = a;};
      bitset<ATTRS> get_elem() const {return(elem);};
      float  get_value() {return(valor);};
};

void coef::set_elem ( vector<int> estos) {
    elem.reset();
    for ( size_t i=0 ; i < estos.size() ; i++) elem.set(estos[i]);
}

class medida {

    private:
        vector<coef> metrica;

    public:
        void initialize(size_t corte);
        void initialize( vector< bitset<ATTRS>  > caminos , size_t corte);
        void initialize( vector < coef> coefs );
        float get_value(bitset<ATTRS> elem);
        void set_value(bitset<ATTRS> elem, float valor);
        void add_value(bitset<ATTRS> elem, float valor);
        void mostrar();
        int cant_elem(){ return metrica.size();};
};

void medida::initialize(vector < coef> coefs){ //inicializa una metrica con los coeficientes que se le suministra

    for(size_t i = 0 ; i< coefs.size() ; i++ ) metrica.push_back(coefs[i]);

}

//inicializa los valores al punto de equilibrio hasta corte sin el conjunto total
void medida::initialize(size_t corte=ATTRS){

        size_t i ;
        coef c;

        vector< bitset<ATTRS> > listado2;
        for (i = 1 ; i <= corte ; i++) combnk(i,listado2);
        for (i = 0; i <= listado2.size() ;  i++ ){
           if(listado2[i].count()==0) continue;
           c.set_elem(listado2[i]);
           c.set_value(listado2[i].count()/(ATTRS+0.0));
           metrica.push_back(c);
        }
}


void medida::initialize( vector< bitset<ATTRS>  > caminos , size_t corte=ATTRS ){

    coef c;
    bitset<ATTRS> a;

    c.set_elem(a); //conj vacio
    c.set_value(0);
    metrica.push_back(c);

   /* a.set(); // conj total
    c.set_elem(a);
    c.set_value(1);
    metrica.push_back(c);
    */

    for(size_t i = 0 ; i< caminos.size() ; i++ ){
        if(caminos[i].count() > corte) continue;
        c.set_elem(caminos[i]);
        c.set_value(caminos[i].count()/(ATTRS+0.0));
        metrica.push_back(c);
     }


}



//dado el elem devuelve el valor de ese coeficiente
float medida::get_value(bitset<ATTRS> elem){

    for( size_t i = 0 ; i< metrica.size() ; i++ )
        if( metrica[i].get_elem() == elem ) return(metrica[i].get_value());

return(-1);
}


//dado el elem cambia el valor del mismo por el que se le pasa como argumento, si no existe lo crea
void medida::set_value(bitset<ATTRS> elem, float valor){

    for( size_t i = 0 ; i< metrica.size() ; i++ ){
        if( metrica[i].get_elem() == elem ) {
            metrica[i].set_value(valor) ;
            return;
        }
    }
    coef c;
    c.set_elem(elem);
    c.set_value(valor);
    metrica.push_back(c);

}

void medida::add_value(bitset<ATTRS> elem, float valor){

    coef c;
    c.set_elem(elem);
    c.set_value(valor);
    metrica.push_back(c);

}


bool comp ( const coef& l, const coef& r){

    return l.get_elem().count() < r.get_elem().count();
}


void medida::mostrar(){
        bitset<ATTRS> elem;
        vector<int> conv;
        size_t i;
        sort (metrica.begin(), metrica.end(), comp);

        for( i = 0 ; i< metrica.size() ; i++ ){

            conv.clear();
            elem  = metrica[i].get_elem();
            bitset2vecint(elem,conv);
            for(size_t j=0 ; j< conv.size() ; j++) conv[j]++;
            cout <<  "Element: "  << setw(ATTRS) << elem << setw(ATTRS) << std::right  << conv << setw(ATTRS*2) <<  " Valor: "<< setprecision(5) << metrica[i].get_value() << endl ;

        }
}

//Funciones auxiliares asociadas a las medidas



//devuelve el valor maximo de los coeficientes estos o -1 si el coef no esta en la metrica
float buscar_maximo ( vector< bitset<ATTRS> > &estos,  medida &metrica) {

    float a, maximo = -1;

    for(size_t i = 0 ; i < estos.size() ; i++ ){
        a = metrica.get_value(estos[i]);

        if( a > maximo ) maximo = a;
    }

 return(maximo);
}


//completa la metrica hasta el nivel CORTE
void completar_metrica(medida &metrica ){

    vector< bitset<ATTRS> > salida, cuales;
    bitset<ATTRS> todos;
    double mv;

    metrica.set_value(todos,0);
    todos.set();
    metrica.set_value(todos,1);

    for ( size_t i = 1 ; i<=CORTE ; i++ ){

        cuales.clear();
        Combination(todos,i,cuales);

        for ( size_t j = 0 ; j < cuales.size(); j++ ){
            mv = metrica.get_value( cuales[j] );
            if( cuales[j].count() == ATTRS ) mv=1;

            if ( mv == -1 ) {
              salida.clear();
              Combination( cuales[j], i-1 ,salida);
              mv = buscar_maximo ( salida,  metrica);
            }
            metrica.set_value(cuales[j],mv);
        }
    }
}

void setear_metrica( medida & metrica, vector< float > valores ) //inicializa la metrica con estos valores
{
        unsigned long T ;
        size_t card , i = 0;

        for ( card = 1; card <= CORTE ;  card++ ){
            for ( T = 0 ; T < pow(2,ATTRS) ; T++ ){

                if ((std::bitset<ATTRS>(T)).count() != card) continue;
                metrica.set_value(std::bitset<ATTRS>(T),valores[i++]);

            }
        }


return;
}




float maxlevelk( vector< bitset<ATTRS> > & levelk , vector< size_t> & orden , medida &metrica , bitset<ATTRS> este ){ //devuelva las combinaciones de los att tomadosdea



  for ( size_t k = 0 ; k < levelk.size() ; k++ ){

        if( (levelk[orden[k]] & este).count() == CORTE ) return (metrica.get_value(levelk[orden[k]])) ;


  }


  return -1;

}



#endif // MEDIDA_H_INCLUDED
